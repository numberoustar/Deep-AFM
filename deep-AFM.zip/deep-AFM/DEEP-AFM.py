from utils.utils import create_dataset, Trainer
from layer.layer import Embedding, FeaturesEmbedding, EmbeddingsInteraction, MultiLayerPerceptron

import torch
import torch.nn as nn
import torch.optim as optim
import argparse
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
print('Training on [{}].'.format(device))
class AttentionNet(nn.Module):

    def __init__(self, embed_dim=4, t=4):
        super(AttentionNet, self).__init__()

        self.an = nn.Sequential(
            nn.Linear(embed_dim, t),  # (batch_size, num_crosses, t), num_crosses = num_fields*(num_fields-1)//2
            nn.ReLU(),
            nn.Linear(t, 1, bias=False),  # (batch_size, num_crosses, 1)
            nn.Flatten(),  # (batch_size, num_crosses)
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        return self.an(x)

class DeepFM(nn.Module):

    def __init__(self, field_dims, embed_dim=4):
        super(DeepFM, self).__init__()

        num_fileds = len(field_dims)

        self.embed1 = FeaturesEmbedding(field_dims, 1)
        self.embed2 = FeaturesEmbedding(field_dims, embed_dim)

        self.fm = EmbeddingsInteraction()
        self.bias = nn.Parameter(torch.zeros((1,)))
        self.deep = MultiLayerPerceptron([embed_dim * num_fileds, 1024, 512, 256])
        self.interact = EmbeddingsInteraction()
        self.w0 = nn.Parameter(torch.zeros((1,)))
        self.attention = AttentionNet(embed_dim)
        self.p = nn.Parameter(torch.zeros(embed_dim, ))
        nn.init.xavier_uniform_(self.p.unsqueeze(0).data)
        #self.fc = nn.Linear(1 + num_fileds * (num_fileds - 1) // 2 + 32, 1)
        self.fc = nn.Linear(257, 1)

    def forward(self, x):
        # x shape: (batch_size, num_fields)
        # embed(x) shape: (batch_size, num_fields, embed_dim)

        #embeddings = self.embed2(x)
        #embeddings_cross = self.fm(embeddings).sum(dim=-1)
        #deep_output = self.deep(embeddings.reshape(x.shape[0], -1))

        #stacked = torch.hstack([self.embed1(x).sum(dim=1), embeddings_cross, deep_output])
        #output = self.fc(stacked)
        # FM部分
        embeddings = self.embed2(x)
        interactions = self.interact(embeddings)

        att = self.attention(interactions)
        att_part = interactions.mul(att.unsqueeze(-1)).sum(dim=1).mul(self.p).sum(dim=1, keepdim=True)

        output = self.w0 + self.embed1(x).sum(dim=1) + att_part
        # Deep部分
        deep_output = self.deep(embeddings.reshape(x.shape[0], -1))
        stacked = torch.hstack([deep_output, output])
        output = self.fc(stacked)
        output = torch.sigmoid(output)
        return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="use FM.")
    parser.add_argument("-d", "--EMBEDDING_DIM", type=int, default=8, help="dimension")
    parser.add_argument("-l", "--LEARNING_RATE", type=float, default=1e-4, help="learning_rate")
    parser.add_argument("-r", "--REGULARIZATION", type=float, default=1e-6, help="regularization")
    parser.add_argument("-b", "--BATCH_SIZE", type=int, default=4096, help="batch size")
    parser.add_argument("-e", "--EPOCH", type=int, default=100, help="number of epoch")
    parser.add_argument("-t", "--TRIAL", type=int, default=100, help="number of trial")
    parser.add_argument("-s", "--sampleNum", type=int, default=100000, help="number of sample")
    args = parser.parse_args()
    dataset = create_dataset('criteo', sample_num=args.sampleNum, device=device)
    field_dims, (train_X, train_y), (valid_X, valid_y), (test_X, test_y) = dataset.train_valid_test_split()
    dfm = DeepFM(field_dims, args.EMBEDDING_DIM).to(device)
    optimizer = optim.Adam(dfm.parameters(), lr=args.LEARNING_RATE, weight_decay=args.REGULARIZATION)
    criterion = nn.BCELoss()

    trainer = Trainer(dfm, optimizer, criterion, args.BATCH_SIZE)
    trainer.train(train_X, train_y, epoch=args.EPOCH, trials=args.TRIAL, valid_X=valid_X, valid_y=valid_y)
    test_loss, test_auc = trainer.test(test_X, test_y)
    print('through the process, the performance of test datasets are as follows:    '
          'test_loss =  {:.5f} & test_auc =  {:.5f}'.format(test_loss, test_auc))